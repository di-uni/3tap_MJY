package com.example.mytab0626;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import android.widget.Toolbar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class TabFragment2 extends Fragment implements FruitAdapter.FruitAdapterListener{

    RecyclerView recyclerView;
    List<Fruits> fruitsList;
    FruitAdapter adapter;

    //Array of fruits names
    String[] names={"Apple","Strawberry","Pomegranates","Oranges","Watermelon","Bananas","Kiwi","Tomato","Grapes"};
    //Array of fruits desc
    String[] sntfNames={"Malus Domestica","Fragaria Ananassa ","Punica Granatum","Citrus Sinensis","Citrullus Vulgaris","Musa Acuminata","Actinidia Deliciosa","Solanum Lycopersicum","Vitis vinifera"};

    //Array of fruits images
    int[] image ={R.drawable.apple,R.drawable.strawberry,R.drawable.pomegranates,R.drawable.oranges,R.drawable.watermelon,R.drawable.banana,R.drawable.kiwi,R.drawable.tomato,R.drawable.grapes};

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View view = inflater.inflate(R.layout.tab_fragment_2, container, false);

        //finding views
        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);

        //item decorator to separate the items
        recyclerView.addItemDecoration(new DividerItemDecoration(getActivity(),DividerItemDecoration.VERTICAL));

        //setting layout
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));


        //initialize fruits list
        fruitsList = new ArrayList<>();



        adapter = new FruitAdapter(getActivity(),fruitsList,this);




        //method to load fruits
        loadfruits();
        //onItemClickListener
        recyclerView.addOnItemTouchListener(new FruitTouchListener(getActivity().getApplicationContext(), new FruitTouchListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {

                Intent intent = new Intent(getContext(), AddingPhonenumber.class);
                intent.putExtra("name",names[position]);
                intent.putExtra("image", image[position]);
                startActivity(intent);
            }
        }));

    return view;
    }



    private void loadfruits() {

        for(int i=0; i<names.length;i++) {

            fruitsList.add(new Fruits(names[i], sntfNames[i], image[i]));
        }
        adapter.notifyDataSetChanged();
        recyclerView.setAdapter(adapter);

    }





    @Override
    public void onFruitSelected(Fruits fruits) {
        Toast.makeText(getContext(), "Selected: " + fruits.getName() , Toast.LENGTH_LONG).show();
    }

}
